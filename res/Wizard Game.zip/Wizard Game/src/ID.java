
public enum ID {
	Player(),
	Block(),
	Crate(),
	Bullet(),
	Enemy();
}
